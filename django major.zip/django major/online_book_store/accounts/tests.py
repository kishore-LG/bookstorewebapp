from django.contrib.auth.models import User
from django.test import TestCase
from django.urls import reverse


class AccountWorkflowTest(TestCase):
    def test_registration_creates_user_and_logs_them_in(self):
        response = self.client.post(
            reverse('accounts:register'),
            {
                'username': 'reader_one',
                'first_name': 'Reader',
                'last_name': 'One',
                'email': 'reader@example.com',
                'password1': 'A-Strong-Test-Pass-839!',
                'password2': 'A-Strong-Test-Pass-839!',
            },
        )

        self.assertEqual(response.status_code, 302)
        user = User.objects.get(username='reader_one')
        self.assertTrue(user.check_password('A-Strong-Test-Pass-839!'))
        self.assertTrue(self.client.session.get('_auth_user_id'))

    def test_login_accepts_valid_credentials(self):
        User.objects.create_user(username='reader_two', password='A-Strong-Test-Pass-839!')

        response = self.client.post(
            reverse('accounts:login'),
            {'username': 'reader_two', 'password': 'A-Strong-Test-Pass-839!'},
        )

        self.assertEqual(response.status_code, 302)
        self.assertTrue(self.client.session.get('_auth_user_id'))
