"""
Cart views - session-based cart system.
"""
from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from django.contrib import messages
from django.views.decorators.http import require_POST
from decimal import Decimal

from books.models import Book


def _get_cart(request):
    """Get or create cart from session."""
    return request.session.get('cart', {})


def _save_cart(request, cart):
    """Save cart to session."""
    request.session['cart'] = cart
    request.session.modified = True


def cart_detail(request):
    """Display the shopping cart."""
    cart = _get_cart(request)
    cart_items = []
    total = Decimal('0.00')

    for book_id, item_data in list(cart.items()):
        try:
            book = Book.objects.get(pk=int(book_id))
            quantity = int(item_data.get('quantity', 1))
            if quantity < 1 or book.stock < 1:
                raise ValueError('Invalid cart quantity or unavailable stock.')
            quantity = min(quantity, book.stock)
            cart[book_id]['quantity'] = quantity
            price = book.effective_price
            subtotal = price * quantity
            total += subtotal
            cart_items.append({
                'book': book,
                'quantity': quantity,
                'price': price,
                'subtotal': subtotal,
            })
        except (Book.DoesNotExist, TypeError, ValueError, AttributeError):
            # Remove orphan cart items
            del cart[book_id]
            _save_cart(request, cart)

    context = {
        'cart_items': cart_items,
        'total': total,
    }
    return render(request, 'cart/cart.html', context)


@require_POST
def add_to_cart(request, book_id):
    """Add a book to the session cart."""
    book = get_object_or_404(Book, pk=book_id)

    if book.stock <= 0:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({'success': False, 'message': 'This book is out of stock.'})
        messages.error(request, f'Sorry, "{book.title}" is out of stock.')
        return redirect('books:book_detail', slug=book.slug)

    cart = _get_cart(request)
    book_key = str(book_id)
    try:
        quantity = int(request.POST.get('quantity', 1))
    except (TypeError, ValueError):
        quantity = 1

    if quantity < 1:
        quantity = 1
    if quantity > book.stock:
        quantity = book.stock

    if book_key in cart:
        new_qty = cart[book_key]['quantity'] + quantity
        cart[book_key]['quantity'] = min(new_qty, book.stock)
    else:
        cart[book_key] = {
            'quantity': quantity,
            'price': str(book.effective_price),
            'title': book.title,
        }

    _save_cart(request, cart)

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        total_count = sum(item['quantity'] for item in cart.values())
        return JsonResponse({
            'success': True,
            'message': f'"{book.title}" added to cart!',
            'cart_count': total_count,
        })

    messages.success(request, f'"{book.title}" has been added to your cart.')
    return redirect('cart:cart_detail')


@require_POST
def update_cart(request, book_id):
    """Update cart item quantity."""
    book = get_object_or_404(Book, pk=book_id)
    cart = _get_cart(request)
    book_key = str(book_id)
    try:
        quantity = int(request.POST.get('quantity', 1))
    except (TypeError, ValueError):
        messages.error(request, 'Enter a valid quantity.')
        return redirect('cart:cart_detail')

    if book_key in cart:
        if quantity <= 0:
            del cart[book_key]
            messages.success(request, f'"{book.title}" removed from cart.')
        elif book.stock <= 0:
            del cart[book_key]
            messages.warning(request, f'"{book.title}" is out of stock and was removed.')
        elif quantity > book.stock:
            cart[book_key]['quantity'] = book.stock
            messages.warning(request, f'Quantity adjusted to available stock ({book.stock}).')
        else:
            cart[book_key]['quantity'] = quantity
            messages.success(request, 'Cart updated.')

    _save_cart(request, cart)
    return redirect('cart:cart_detail')


@require_POST
def remove_from_cart(request, book_id):
    """Remove a book from the cart."""
    book = get_object_or_404(Book, pk=book_id)
    cart = _get_cart(request)
    book_key = str(book_id)

    if book_key in cart:
        del cart[book_key]
        _save_cart(request, cart)
        messages.success(request, f'"{book.title}" removed from cart.')

    return redirect('cart:cart_detail')


@require_POST
def clear_cart(request):
    """Clear entire cart."""
    request.session['cart'] = {}
    request.session.modified = True
    messages.success(request, 'Your cart has been cleared.')
    return redirect('cart:cart_detail')
