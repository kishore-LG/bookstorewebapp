from decimal import Decimal

from django.test import TestCase
from django.urls import reverse

from books.models import Book, Category


class CartWorkflowTest(TestCase):
    def setUp(self):
        category = Category.objects.create(name='Fiction')
        self.book = Book.objects.create(
            title='Cart Test Book',
            author='Test Author',
            category=category,
            description='A book used to test cart behavior.',
            price=Decimal('15.00'),
            stock=4,
        )

    def test_add_invalid_quantity_defaults_to_one(self):
        response = self.client.post(
            reverse('cart:add_to_cart', args=[self.book.pk]),
            {'quantity': 'not-a-number'},
        )

        self.assertEqual(response.status_code, 302)
        self.assertEqual(self.client.session['cart'][str(self.book.pk)]['quantity'], 1)

    def test_cart_uses_current_database_price(self):
        session = self.client.session
        session['cart'] = {
            str(self.book.pk): {'quantity': 2, 'price': '0.01'}
        }
        session.save()

        response = self.client.get(reverse('cart:cart_detail'))

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context['total'], Decimal('30.00'))
        self.assertContains(response, '$15.00')

    def test_clear_cart_requires_post(self):
        session = self.client.session
        session['cart'] = {str(self.book.pk): {'quantity': 1}}
        session.save()

        response = self.client.get(reverse('cart:clear_cart'))

        self.assertEqual(response.status_code, 405)
        self.assertIn(str(self.book.pk), self.client.session['cart'])
