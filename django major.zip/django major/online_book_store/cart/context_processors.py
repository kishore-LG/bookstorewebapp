"""
Cart context processor to provide cart item count globally.
"""


def cart_count(request):
    """Add cart item count to every template context."""
    cart = request.session.get('cart', {})
    count = sum(item.get('quantity', 0) for item in cart.values())
    return {'cart_count': count}
