@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    where py >nul 2>nul
    if not errorlevel 1 (
        py -3.11 -m venv .venv >nul 2>nul
        if errorlevel 1 py -m venv .venv
    ) else (
        python -m venv .venv
    )
    if errorlevel 1 goto :failed
)

set "PYTHON=.venv\Scripts\python.exe"
%PYTHON% -m pip install --upgrade pip
if errorlevel 1 goto :failed
%PYTHON% -m pip install -r requirements.txt
if errorlevel 1 goto :failed

if not exist ".env" (
    copy ".env.example" ".env" >nul
    echo Created .env from .env.example. Gemini API access is optional.
)

%PYTHON% manage.py migrate
if errorlevel 1 goto :failed
%PYTHON% manage.py seed_data
if errorlevel 1 goto :failed

choice /C YN /M "Create a Django superuser now"
if errorlevel 2 goto :start_server
%PYTHON% manage.py createsuperuser
if errorlevel 1 goto :failed

:start_server
echo Store: http://127.0.0.1:8000/
echo Admin: http://127.0.0.1:8000/admin/
%PYTHON% manage.py runserver
exit /b %errorlevel%

:failed
echo Setup stopped because a command failed. Review the output above and retry.
exit /b 1
