from django.contrib import admin
from .models import Book, Category, Review


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'slug', 'description']
    search_fields = ['name']
    prepopulated_fields = {'slug': ('name',)}


@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = [
        'title', 'author', 'category', 'price', 'discount_price',
        'stock', 'average_rating', 'is_best_seller', 'is_new_arrival', 'is_featured', 'date_added'
    ]
    list_filter = ['category', 'is_best_seller', 'is_new_arrival', 'is_featured', 'has_audiobook']
    search_fields = ['title', 'author', 'isbn']
    prepopulated_fields = {'slug': ('title',)}
    list_editable = ['price', 'discount_price', 'stock', 'is_best_seller', 'is_new_arrival', 'is_featured']
    ordering = ['-date_added']
    fieldsets = (
        ('Book Information', {
            'fields': ('title', 'author', 'isbn', 'slug', 'category', 'description')
        }),
        ('Pricing & Stock', {
            'fields': ('price', 'discount_price', 'stock')
        }),
        ('Cover Image', {
            'fields': ('cover_image', 'cover_image_url'),
            'description': 'Either upload an image or provide a URL.'
        }),
        ('Metadata', {
            'fields': ('average_rating', 'publication_date', 'has_audiobook')
        }),
        ('Flags', {
            'fields': ('is_best_seller', 'is_new_arrival', 'is_featured')
        }),
    )


@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ['book', 'user', 'rating', 'created_at']
    list_filter = ['rating']
    search_fields = ['book__title', 'user__username']
    readonly_fields = ['created_at']
