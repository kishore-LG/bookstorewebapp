from django.shortcuts import render, get_object_or_404, redirect
from django.core.paginator import Paginator
from django.db.models import Q
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.contrib import messages
from django.core.cache import cache

from .models import Book, Category
from .forms import SearchForm
from .services import get_gemini_summary


def home(request):
    """Homepage view with all sections."""
    best_sellers = Book.objects.filter(is_best_seller=True, stock__gt=0).select_related('category')[:8]
    new_arrivals = Book.objects.filter(is_new_arrival=True, stock__gt=0).select_related('category')[:8]
    featured_books = Book.objects.filter(is_featured=True, stock__gt=0).select_related('category')[:4]
    categories = Category.objects.all()
    context = {
        'best_sellers': best_sellers,
        'new_arrivals': new_arrivals,
        'featured_books': featured_books,
        'categories': categories,
        'search_form': SearchForm(),
    }
    return render(request, 'home.html', context)


def book_list(request):
    """View all books with search, filter, sort, and pagination."""
    books = Book.objects.select_related('category').all()
    categories = Category.objects.all()
    form = SearchForm(request.GET)

    query = request.GET.get('q', '').strip()
    category_slug = request.GET.get('category', '').strip()
    sort_by = request.GET.get('sort', '-date_added')
    min_price = request.GET.get('min_price', '')
    max_price = request.GET.get('max_price', '')

    if query:
        books = books.filter(
            Q(title__icontains=query) |
            Q(author__icontains=query) |
            Q(isbn__icontains=query)
        )

    if category_slug:
        books = books.filter(category__slug=category_slug)

    if min_price:
        try:
            books = books.filter(price__gte=float(min_price))
        except ValueError:
            pass

    if max_price:
        try:
            books = books.filter(price__lte=float(max_price))
        except ValueError:
            pass

    # Sorting options
    sort_options = {
        'title': 'title',
        '-title': '-title',
        'price': 'price',
        '-price': '-price',
        '-date_added': '-date_added',
        'date_added': 'date_added',
        '-average_rating': '-average_rating',
    }
    order_field = sort_options.get(sort_by, '-date_added')
    books = books.order_by(order_field)

    paginator = Paginator(books, 12)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    context = {
        'page_obj': page_obj,
        'categories': categories,
        'form': form,
        'query': query,
        'selected_category': category_slug,
        'sort_by': sort_by,
        'min_price': min_price,
        'max_price': max_price,
        'total_books': books.count(),
    }
    return render(request, 'books/book_list.html', context)


def book_detail(request, slug):
    """Individual book detail page."""
    book = get_object_or_404(Book, slug=slug)
    related_books = Book.objects.filter(
        category=book.category
    ).exclude(pk=book.pk).select_related('category')[:4]

    context = {
        'book': book,
        'related_books': related_books,
    }
    return render(request, 'books/book_detail.html', context)


def category_books(request, slug):
    """Books filtered by category."""
    category = get_object_or_404(Category, slug=slug)
    books = Book.objects.filter(category=category, stock__gt=0).select_related('category')

    sort_by = request.GET.get('sort', '-date_added')
    sort_options = {
        'title': 'title',
        '-title': '-title',
        'price': 'price',
        '-price': '-price',
        '-date_added': '-date_added',
        '-average_rating': '-average_rating',
    }
    order_field = sort_options.get(sort_by, '-date_added')
    books = books.order_by(order_field)

    paginator = Paginator(books, 12)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    categories = Category.objects.all()
    context = {
        'category': category,
        'page_obj': page_obj,
        'categories': categories,
        'sort_by': sort_by,
    }
    return render(request, 'books/category_books.html', context)


@require_POST
def generate_ai_summary(request, slug):
    """AJAX endpoint to generate an AI summary for a book."""
    client_ip = request.META.get('REMOTE_ADDR', 'unknown')
    cache_key = f'ai-summary:{client_ip}'
    if not cache.add(cache_key, 1, timeout=3600):
        request_count = cache.incr(cache_key)
        if request_count > 10:
            return JsonResponse({
                'success': False,
                'error': 'Summary request limit reached. Please try again in an hour.',
            }, status=429)

    book = get_object_or_404(Book, slug=slug)
    category_name = book.category.name if book.category else 'General'

    result = get_gemini_summary(
        title=book.title,
        author=book.author,
        category=category_name,
        description=book.description,
    )
    return JsonResponse(result)


def handler404(request, exception):
    """Custom 404 error handler."""
    return render(request, 'errors/404.html', status=404)


def handler500(request):
    """Custom 500 error handler."""
    return render(request, 'errors/500.html', status=500)
