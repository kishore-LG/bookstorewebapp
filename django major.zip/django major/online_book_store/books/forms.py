from django import forms


class SearchForm(forms.Form):
    """Book search form."""
    q = forms.CharField(
        max_length=200,
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control search-input',
            'placeholder': 'Search by title, author, or ISBN...',
            'id': 'search-input',
        })
    )
    category = forms.CharField(required=False, widget=forms.HiddenInput())
    sort = forms.CharField(required=False, widget=forms.HiddenInput())
    min_price = forms.DecimalField(required=False, widget=forms.HiddenInput())
    max_price = forms.DecimalField(required=False, widget=forms.HiddenInput())
