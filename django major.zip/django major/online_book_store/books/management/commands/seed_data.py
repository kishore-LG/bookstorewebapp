"""
Management command to seed the database with sample book data.
Run: python manage.py seed_data
"""
from django.core.management.base import BaseCommand
from books.models import Category, Book


CATEGORIES = [
    {'name': 'Fiction', 'description': 'Novels, short stories, and imaginative narratives', 'icon': 'bi-book'},
    {'name': 'Non-Fiction', 'description': 'Factual books on real events, people, and ideas', 'icon': 'bi-journal-text'},
    {'name': 'Education', 'description': 'Academic and learning resources', 'icon': 'bi-mortarboard'},
    {'name': 'Technology', 'description': 'Programming, software, and digital innovation', 'icon': 'bi-laptop'},
    {'name': 'Biography', 'description': 'Life stories of remarkable people', 'icon': 'bi-person-circle'},
    {'name': 'Science', 'description': 'Discoveries and knowledge about our world', 'icon': 'bi-flask'},
    {'name': 'Self-Help', 'description': 'Personal growth and improvement guides', 'icon': 'bi-lightbulb'},
    {'name': 'History', 'description': 'Historical events and civilizations', 'icon': 'bi-hourglass-split'},
]

BOOKS = [
    # Fiction
    {
        'title': 'The Midnight Library',
        'author': 'Matt Haig',
        'isbn': '978-0525559474',
        'category': 'Fiction',
        'description': 'Between life and death there is a library. When Nora Seed finds herself in the Midnight Library, she has a chance to make things right. Up until now, her life has been full of misery and regret. She feels she has let everyone down, including herself. But things are about to change. The books in the Midnight Library enable Nora to live as if she had done things differently. With the help of an old friend, she can now undo every one of her regrets as she tries to work out her perfect life. But things might not be what she imagined.',
        'price': 14.99,
        'discount_price': 11.99,
        'cover_image_url': 'https://covers.openlibrary.org/b/isbn/9780525559474-L.jpg',
        'stock': 25,
        'average_rating': 4.5,
        'is_best_seller': True,
        'is_featured': True,
        'is_new_arrival': False,
    },
    {
        'title': 'The Alchemist',
        'author': 'Paulo Coelho',
        'isbn': '978-0062315007',
        'category': 'Fiction',
        'description': "Paulo Coelho's masterwork tells the magical story of Santiago, an Andalusian shepherd boy who yearns to travel in search of a worldly treasure. His quest will lead him to riches far different—and far more satisfying—than he ever imagined. Santiago's journey teaches us about the essential wisdom of listening to our hearts, of recognizing opportunity and learning to read the omens strewn along life's path, and, most importantly, to follow our dreams.",
        'price': 12.99,
        'cover_image_url': 'https://covers.openlibrary.org/b/isbn/9780062315007-L.jpg',
        'stock': 30,
        'average_rating': 4.7,
        'is_best_seller': True,
        'is_featured': False,
        'is_new_arrival': False,
    },
    {
        'title': 'Atomic Habits',
        'author': 'James Clear',
        'isbn': '978-0735211292',
        'category': 'Self-Help',
        'description': "No matter your goals, Atomic Habits offers a proven framework for improving—every day. James Clear, one of the world's leading experts on habit formation, reveals practical strategies that will teach you exactly how to form good habits, break bad ones, and master the tiny behaviors that lead to remarkable results. If you're having trouble changing your habits, the problem isn't you. The problem is your system. Bad habits repeat themselves again and again not because you don't want to change, but because you have the wrong system for change.",
        'price': 16.99,
        'discount_price': 13.99,
        'cover_image_url': 'https://covers.openlibrary.org/b/isbn/9780735211292-L.jpg',
        'stock': 40,
        'average_rating': 4.8,
        'is_best_seller': True,
        'is_featured': True,
        'is_new_arrival': False,
    },
    {
        'title': 'Python Crash Course',
        'author': 'Eric Matthes',
        'isbn': '978-1718502703',
        'category': 'Technology',
        'description': "Python Crash Course is the world's best-selling guide to the Python programming language. This fast-paced, thorough introduction will have you writing programs, solving problems, and making things that work in no time. In the first half of the book, you'll learn about basic programming concepts, such as lists, dictionaries, classes, and loops, and practice writing clean and readable code with exercises for each topic.",
        'price': 35.99,
        'discount_price': 29.99,
        'cover_image_url': 'https://covers.openlibrary.org/b/isbn/9781718502703-L.jpg',
        'stock': 20,
        'average_rating': 4.6,
        'is_best_seller': True,
        'is_featured': True,
        'is_new_arrival': True,
    },
    {
        'title': 'Sapiens: A Brief History of Humankind',
        'author': 'Yuval Noah Harari',
        'isbn': '978-0062316097',
        'category': 'History',
        'description': "100,000 years ago, at least six human species inhabited the earth. Today there is just one. Us. Homo sapiens. How did our species succeed in the battle for dominance? Why did our foraging ancestors come together to create cities and kingdoms? How did we come to believe in gods, nations and human rights; to trust money, books and laws; and to be enslaved by bureaucracy, timetables and consumerism? And what will our world be like in the millennia to come?",
        'price': 18.99,
        'cover_image_url': 'https://covers.openlibrary.org/b/isbn/9780062316097-L.jpg',
        'stock': 35,
        'average_rating': 4.5,
        'is_best_seller': False,
        'is_featured': True,
        'is_new_arrival': False,
    },
    {
        'title': 'Becoming',
        'author': 'Michelle Obama',
        'isbn': '978-1524763138',
        'category': 'Biography',
        'description': "In a life filled with meaning and accomplishment, Michelle Obama has emerged as one of the most iconic and compelling women of our era. As First Lady of the United States of America—the first African American to serve in that role—she helped create the most welcoming and inclusive White House in history, while also establishing herself as a powerful advocate for women and girls in the U.S. and around the world, dramatically changing the ways that families pursue healthier and more active lives, and standing with her husband as he led America through some of its most harrowing moments.",
        'price': 19.99,
        'discount_price': 15.99,
        'cover_image_url': 'https://covers.openlibrary.org/b/isbn/9781524763138-L.jpg',
        'stock': 22,
        'average_rating': 4.7,
        'is_best_seller': True,
        'is_featured': False,
        'is_new_arrival': False,
    },
    {
        'title': 'Clean Code',
        'author': 'Robert C. Martin',
        'isbn': '978-0132350884',
        'category': 'Technology',
        'description': "Even bad code can function. But if code isn't clean, it can bring a development organization to its knees. Every year, countless hours and significant resources are lost because of poorly written code. But it doesn't have to be that way. Noted software expert Robert C. Martin presents a revolutionary paradigm with Clean Code: A Handbook of Agile Software Craftsmanship. Martin has teamed up with his colleagues from Object Mentor to distill their best agile practice of cleaning code \"on the fly\" into a book that will instill within you the values of a software craftsman and make you a better programmer.",
        'price': 42.99,
        'cover_image_url': 'https://covers.openlibrary.org/b/isbn/9780132350884-L.jpg',
        'stock': 15,
        'average_rating': 4.6,
        'is_best_seller': False,
        'is_featured': False,
        'is_new_arrival': True,
    },
    {
        'title': 'The Great Gatsby',
        'author': 'F. Scott Fitzgerald',
        'isbn': '978-0743273565',
        'category': 'Fiction',
        'description': "The Great Gatsby, F. Scott Fitzgerald's third book, stands as the supreme achievement of his career. This exemplary novel of the Jazz Age has been acclaimed by generations of readers. The story of the fabulously wealthy Jay Gatsby and his love for the beautiful Daisy Buchanan, of lavish parties on Long Island at a time when The New York Times noted \"gin was the national drink and sex the national obsession,\" it is an exquisitely crafted tale of America in the 1920s.",
        'price': 10.99,
        'cover_image_url': 'https://covers.openlibrary.org/b/isbn/9780743273565-L.jpg',
        'stock': 50,
        'average_rating': 4.3,
        'is_best_seller': False,
        'is_featured': False,
        'is_new_arrival': False,
    },
    {
        'title': 'A Brief History of Time',
        'author': 'Stephen Hawking',
        'isbn': '978-0553380163',
        'category': 'Science',
        'description': "Was there a beginning of time? Could time run backwards? Is the universe infinite or does it have boundaries? These are just three of the questions considered in an internationally acclaimed masterpiece by one of the world's greatest thinkers. It begins by reviewing the great theories of the cosmos from Newton to Einstein, before delving into the secrets which still lie at the heart of space and time, from the Big Bang to black holes, via spiral galaxies and strong theory.",
        'price': 13.99,
        'cover_image_url': 'https://covers.openlibrary.org/b/isbn/9780553380163-L.jpg',
        'stock': 28,
        'average_rating': 4.4,
        'is_best_seller': False,
        'is_featured': True,
        'is_new_arrival': False,
    },
    {
        'title': 'Think and Grow Rich',
        'author': 'Napoleon Hill',
        'isbn': '978-1585424337',
        'category': 'Self-Help',
        'description': "This is the original 1937 classic. Think and Grow Rich has been called the Granddaddy of All Motivational Literature. It was the first book to boldly ask, What makes a winner? The man who asked and listened for the answer, Napoleon Hill, is now counted in the top ranks of the world's greatest winners himself. The most famous of all teachers of success spent a fortune and the better part of a lifetime of effort to produce the Law of Success philosophy.",
        'price': 11.99,
        'cover_image_url': 'https://covers.openlibrary.org/b/isbn/9781585424337-L.jpg',
        'stock': 33,
        'average_rating': 4.2,
        'is_best_seller': False,
        'is_featured': False,
        'is_new_arrival': False,
    },
    {
        'title': '1984',
        'author': 'George Orwell',
        'isbn': '978-0451524935',
        'category': 'Fiction',
        'description': "Written in 1948, 1984 was George Orwell's chilling prophecy about the future. And while 1984 has come and gone, Orwell's narrative is timelier than ever. 1984 presents a startling and haunting vision of the world, so powerful that it is completely convincing from start to finish. No one can deny the power of this novel, its hold on the imaginations of multiple generations of readers, or the resiliency of its admonitions—a legacy that seems only to grow with the passage of time.",
        'price': 9.99,
        'cover_image_url': 'https://covers.openlibrary.org/b/isbn/9780451524935-L.jpg',
        'stock': 45,
        'average_rating': 4.7,
        'is_best_seller': True,
        'is_featured': True,
        'is_new_arrival': False,
    },
    {
        'title': 'Introduction to Algorithms',
        'author': 'Thomas H. Cormen',
        'isbn': '978-0262033848',
        'category': 'Education',
        'description': "Some books on algorithms are rigorous but incomplete; others cover masses of material but lack rigor. Introduction to Algorithms uniquely combines rigor and comprehensiveness. The book covers a broad range of algorithms in depth, yet makes their design and analysis accessible to all levels of readers. Each chapter is relatively self-contained and can be used as a unit of study. The algorithms are described in English and in a pseudocode designed to be readable by anyone who has done a little programming.",
        'price': 89.99,
        'discount_price': 74.99,
        'cover_image_url': 'https://covers.openlibrary.org/b/isbn/9780262033848-L.jpg',
        'stock': 12,
        'average_rating': 4.5,
        'is_best_seller': False,
        'is_featured': False,
        'is_new_arrival': True,
    },
    {
        'title': 'The Power of Now',
        'author': 'Eckhart Tolle',
        'isbn': '978-1577314806',
        'category': 'Self-Help',
        'description': "To make the journey into the Now we will need to leave our analytical mind and its false created self, the ego, behind. From the very first page of Eckhart Tolle's extraordinary book, we move rapidly into a significantly higher altitude where we breathe a different air. The air of transformation. The Power of Now is a guide to spiritual enlightenment. Tolle is a contemporary spiritual teacher who was born in Germany and educated at the Universities of London and Cambridge.",
        'price': 14.99,
        'cover_image_url': 'https://covers.openlibrary.org/b/isbn/9781577314806-L.jpg',
        'stock': 20,
        'average_rating': 4.3,
        'is_best_seller': False,
        'is_featured': False,
        'is_new_arrival': True,
    },
    {
        'title': 'Steve Jobs',
        'author': 'Walter Isaacson',
        'isbn': '978-1451648539',
        'category': 'Biography',
        'description': "Based on more than forty interviews with Jobs conducted over two years—as well as interviews with more than a hundred family members, friends, adversaries, competitors, and colleagues—Walter Isaacson has written a riveting story of the roller-coaster life and searingly intense personality of a creative entrepreneur whose passion for perfection and ferocious drive revolutionized six industries: personal computers, animated movies, music, phones, tablet computing, and digital publishing.",
        'price': 22.99,
        'discount_price': 18.99,
        'cover_image_url': 'https://covers.openlibrary.org/b/isbn/9781451648539-L.jpg',
        'stock': 18,
        'average_rating': 4.4,
        'is_best_seller': True,
        'is_featured': False,
        'is_new_arrival': False,
    },
    {
        'title': 'Harry Potter and the Sorcerer\'s Stone',
        'author': 'J.K. Rowling',
        'isbn': '978-0590353427',
        'category': 'Fiction',
        'description': "Harry Potter has never even heard of Hogwarts when the letters start dropping on the doormat at number four, Privet Drive. Addressed in green ink on yellowish parchment with a purple seal, they are swiftly confiscated by his grim aunt and uncle. Then, on Harry's eleventh birthday, a great beetle-eyed giant of a man called Rubeus Hagrid bursts in with some astonishing news: Harry Potter is a Wizard, and he has a place at Hogwarts School of Witchcraft and Wizardry.",
        'price': 13.99,
        'cover_image_url': 'https://covers.openlibrary.org/b/isbn/9780590353427-L.jpg',
        'stock': 60,
        'average_rating': 4.9,
        'is_best_seller': True,
        'is_featured': True,
        'is_new_arrival': False,
        'has_audiobook': True,
    },
    {
        'title': 'The Origin of Species',
        'author': 'Charles Darwin',
        'isbn': '978-0140432053',
        'category': 'Science',
        'description': "The Origin of Species, published on 24 November 1859, is a work of scientific literature by Charles Darwin which is considered to be the foundation of evolutionary biology. Darwin's book introduced the scientific theory that populations evolve over the course of generations through a process of natural selection. It presented a body of evidence that the diversity of life arose by common descent through a branching pattern of evolution.",
        'price': 8.99,
        'cover_image_url': 'https://covers.openlibrary.org/b/isbn/9780140432053-L.jpg',
        'stock': 22,
        'average_rating': 4.1,
        'is_best_seller': False,
        'is_featured': False,
        'is_new_arrival': False,
    },
    {
        'title': 'Django for Beginners',
        'author': 'William S. Vincent',
        'isbn': '978-1735467238',
        'category': 'Technology',
        'description': "Django for Beginners is a project-based introduction to Django, the popular Python-based web framework. Suitable for total beginners who have never built a website before as well as professional programmers looking for a fast-paced guide to modern web development and Django fundamentals. In the book you'll build 5 progressively more complex web applications, starting with a simple Hello, World app, progressing to a Pages app, a Message Board app, a Blog app with forms and user accounts, and finally a robust Newspaper app that features a custom user model, complete user authentication flow, emails, foreign keys, authorization, permissions, and more.",
        'price': 39.99,
        'discount_price': 34.99,
        'cover_image_url': 'https://covers.openlibrary.org/b/isbn/9781735467238-L.jpg',
        'stock': 17,
        'average_rating': 4.6,
        'is_best_seller': False,
        'is_featured': True,
        'is_new_arrival': True,
    },
    {
        'title': 'The Psychology of Money',
        'author': 'Morgan Housel',
        'isbn': '978-0857197689',
        'category': 'Non-Fiction',
        'description': "Doing well with money isn't necessarily about what you know. It's about how you behave. And behavior is hard to teach, even to really smart people. Money—investing, personal finance, and business decisions—is typically taught as a math-based field, where data and formulas tell us exactly what to do. But in the real world people don't make financial decisions on a spreadsheet. They make them at the dinner table, or in a meeting room, where personal history, your own unique view of the world, ego, pride, marketing, and odd incentives are scrambled together.",
        'price': 17.99,
        'discount_price': 14.99,
        'cover_image_url': 'https://covers.openlibrary.org/b/isbn/9780857197689-L.jpg',
        'stock': 38,
        'average_rating': 4.7,
        'is_best_seller': True,
        'is_featured': True,
        'is_new_arrival': True,
    },
    {
        'title': 'Educated',
        'author': 'Tara Westover',
        'isbn': '978-0399590504',
        'category': 'Biography',
        'description': "An unforgettable memoir about a young girl who, kept out of school, leaves her survivalist family and goes on to earn a PhD from Cambridge University. Born to survivalists in the mountains of Idaho, Tara Westover was seventeen the first time she set foot in a classroom. Her family was so isolated from mainstream society that there was no one to ensure the children received an education, and no one to intervene when one of Tara's older brothers became violent.",
        'price': 16.99,
        'cover_image_url': 'https://covers.openlibrary.org/b/isbn/9780399590504-L.jpg',
        'stock': 24,
        'average_rating': 4.6,
        'is_best_seller': False,
        'is_featured': False,
        'is_new_arrival': True,
    },
    {
        'title': 'The 7 Habits of Highly Effective People',
        'author': 'Stephen R. Covey',
        'isbn': '978-1982137274',
        'category': 'Self-Help',
        'description': "One of the most inspiring and impactful books ever written, The 7 Habits of Highly Effective People has captivated readers for nearly three decades. It has transformed the lives of presidents and CEOs, educators and parents—in short, millions of people of all ages and occupations have benefited from Dr. Covey's 7 Habits book. And it can transform you.",
        'price': 15.99,
        'discount_price': 12.99,
        'cover_image_url': 'https://covers.openlibrary.org/b/isbn/9781982137274-L.jpg',
        'stock': 32,
        'average_rating': 4.5,
        'is_best_seller': True,
        'is_featured': False,
        'is_new_arrival': False,
    },
]


class Command(BaseCommand):
    help = 'Seed the database with sample categories and books.'

    def add_arguments(self, parser):
        parser.add_argument(
            '--clear',
            action='store_true',
            help='Clear existing books and categories before seeding.',
        )

    def handle(self, *args, **options):
        if options['clear']:
            self.stdout.write('Clearing existing data...')
            Book.objects.all().delete()
            Category.objects.all().delete()
            self.stdout.write(self.style.WARNING('Existing data cleared.'))

        # Create categories
        self.stdout.write('Creating categories...')
        categories = {}
        for cat_data in CATEGORIES:
            cat, created = Category.objects.get_or_create(
                name=cat_data['name'],
                defaults={
                    'description': cat_data['description'],
                    'icon': cat_data['icon'],
                }
            )
            categories[cat_data['name']] = cat
            action = 'Created' if created else 'Already exists'
            self.stdout.write(f'  {action}: {cat.name}')

        # Create books
        self.stdout.write('Creating books...')
        created_count = 0
        skipped_count = 0
        for book_data in BOOKS:
            cat_name = book_data.pop('category')
            category = categories.get(cat_name)
            isbn = book_data.get('isbn')

            # Check if book already exists
            if isbn and Book.objects.filter(isbn=isbn).exists():
                self.stdout.write(f'  Skipping (exists): {book_data["title"]}')
                book_data['category'] = cat_name  # restore
                skipped_count += 1
                continue

            book = Book.objects.create(category=category, **book_data)
            self.stdout.write(f'  Created: {book.title}')
            created_count += 1

        self.stdout.write(
            self.style.SUCCESS(
                f'\n✓ Seeding complete! Created {created_count} books, skipped {skipped_count}.'
            )
        )
        self.stdout.write(
            self.style.SUCCESS('You can now run the development server: python manage.py runserver')
        )
