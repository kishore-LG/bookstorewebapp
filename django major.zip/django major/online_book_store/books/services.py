"""
AI service for generating book summaries using Google Gemini API.
"""
import os
import logging
import requests
from django.conf import settings

logger = logging.getLogger(__name__)


def get_gemini_summary(title: str, author: str, category: str, description: str) -> dict:
    """
    Generate a concise book summary using Google Gemini AI.

    Args:
        title: Book title
        author: Book author
        category: Book category name
        description: Existing book description

    Returns:
        dict with keys:
            'success': bool
            'summary': str (AI summary or fallback)
            'error': str or None
    """
    api_key = getattr(settings, 'GEMINI_API_KEY', '') or os.environ.get('GEMINI_API_KEY', '')

    if not api_key or api_key == 'your-gemini-api-key-here':
        return {
            'success': False,
            'summary': description,
            'error': 'Gemini API key is not configured. Please set GEMINI_API_KEY in your .env file.'
        }

    # Validate inputs
    if not title or not author:
        return {
            'success': False,
            'summary': description,
            'error': 'Missing required book information (title or author).'
        }

    prompt = (
        "Write a concise 100-150 word reading guide based only on the supplied metadata. "
        "Do not invent plot details or imply that you know the book's contents. "
        "Mention that this is an AI-generated overview, not a verified synopsis.\n\n"
        f"Title: {title[:255]}\n"
        f"Author: {author[:255]}\n"
        f"Category: {category[:100]}\n"
        f"Description: {description[:1000] if description else 'No description available'}"
    )

    try:
        model = getattr(settings, 'GEMINI_MODEL', 'gemini-2.5-flash')
        response = requests.post(
            f'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent',
            headers={'x-goog-api-key': api_key},
            json={
                'contents': [{'parts': [{'text': prompt}]}],
                'generationConfig': {'maxOutputTokens': 300, 'temperature': 0.7},
            },
            timeout=(5, 30),
        )
        if response.status_code == 429:
            return {
                'success': False,
                'summary': description,
                'error': 'Gemini rate limit reached. Please try again later.',
            }
        if response.status_code in (400, 403):
            return {
                'success': False,
                'summary': description,
                'error': 'Gemini could not authorize this request. Check the API key and model access.',
            }
        response.raise_for_status()
        candidates = response.json().get('candidates', [])
        parts = candidates[0].get('content', {}).get('parts', []) if candidates else []
        summary = ' '.join(part.get('text', '') for part in parts).strip()
        if summary:
            return {
                'success': True,
                'summary': summary,
                'error': None
            }
        return {
            'success': False,
            'summary': description,
            'error': 'The AI service returned an empty response. Please try again.'
        }

    except requests.Timeout:
        return {
            'success': False,
            'summary': description,
            'error': 'Gemini request timed out. Please try again in a moment.',
        }
    except requests.RequestException as exc:
        logger.warning("Gemini API request failed: %s", exc)
        return {
            'success': False,
            'summary': description,
            'error': 'Gemini is temporarily unavailable. Showing the book description instead.',
        }
    except Exception as exc:
        logger.exception("Unexpected Gemini response error")
        return {
            'success': False,
            'summary': description,
            'error': 'Gemini is temporarily unavailable. Showing the book description instead.'
        }
