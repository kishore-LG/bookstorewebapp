from django.test import TestCase, Client
from django.contrib.auth.models import User
from django.urls import reverse
from django.test import override_settings
from django.core.cache import cache
from unittest.mock import patch
import requests
from .models import Book, Category
from .services import get_gemini_summary


class CategoryModelTest(TestCase):
    def setUp(self):
        self.category = Category.objects.create(name='Fiction', description='Fiction books')

    def test_category_str(self):
        self.assertEqual(str(self.category), 'Fiction')

    def test_category_slug_auto_generated(self):
        self.assertEqual(self.category.slug, 'fiction')


class BookModelTest(TestCase):
    def setUp(self):
        self.category = Category.objects.create(name='Technology')
        self.book = Book.objects.create(
            title='Python Programming',
            author='John Doe',
            category=self.category,
            description='A comprehensive guide to Python.',
            price=29.99,
            stock=10,
        )

    def test_book_str(self):
        self.assertIn('Python Programming', str(self.book))

    def test_book_slug_auto_generated(self):
        self.assertTrue(self.book.slug)

    def test_book_effective_price_without_discount(self):
        self.assertEqual(self.book.effective_price, self.book.price)

    def test_book_effective_price_with_discount(self):
        self.book.discount_price = 19.99
        self.book.save()
        self.assertEqual(float(self.book.effective_price), 19.99)

    def test_book_discount_percentage(self):
        self.book.discount_price = 24.00
        self.book.save()
        self.assertGreater(self.book.discount_percentage, 0)


class HomeViewTest(TestCase):
    def setUp(self):
        self.client = Client()
        self.category = Category.objects.create(name='Fiction')
        self.book = Book.objects.create(
            title='Test Book',
            author='Test Author',
            category=self.category,
            description='Test description',
            price=15.99,
            stock=5,
            is_best_seller=True,
            is_new_arrival=True,
            is_featured=True,
        )

    def test_home_page_loads(self):
        response = self.client.get(reverse('books:home'))
        self.assertEqual(response.status_code, 200)

    def test_book_list_page_loads(self):
        response = self.client.get(reverse('books:book_list'))
        self.assertEqual(response.status_code, 200)

    def test_book_detail_page_loads(self):
        response = self.client.get(reverse('books:book_detail', args=[self.book.slug]))
        self.assertEqual(response.status_code, 200)

    def test_category_books_page_loads(self):
        response = self.client.get(reverse('books:category_books', args=[self.category.slug]))
        self.assertEqual(response.status_code, 200)

    def test_book_search(self):
        response = self.client.get(reverse('books:book_list') + '?q=Test')
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Test Book')

    def test_book_404(self):
        response = self.client.get(reverse('books:book_detail', args=['non-existent-book']))
        self.assertEqual(response.status_code, 404)


class GeminiSummaryTest(TestCase):
    @override_settings(GEMINI_API_KEY='')
    @patch.dict('os.environ', {'GEMINI_API_KEY': ''})
    def test_missing_api_key_returns_description_fallback(self):
        result = get_gemini_summary('A Title', 'An Author', 'Fiction', 'Stored description')

        self.assertFalse(result['success'])
        self.assertEqual(result['summary'], 'Stored description')
        self.assertIn('not configured', result['error'])

    @override_settings(GEMINI_API_KEY='test-key')
    @patch('books.services.requests.post')
    def test_rate_limit_returns_description_fallback(self, post):
        post.return_value.status_code = 429

        result = get_gemini_summary('A Title', 'An Author', 'Fiction', 'Stored description')

        self.assertFalse(result['success'])
        self.assertEqual(result['summary'], 'Stored description')
        self.assertIn('rate limit', result['error'])
        post.assert_called_once()

    @override_settings(GEMINI_API_KEY='test-key')
    @patch('books.services.requests.post', side_effect=requests.Timeout)
    def test_timeout_returns_description_fallback(self, post):
        result = get_gemini_summary('A Title', 'An Author', 'Fiction', 'Stored description')

        self.assertFalse(result['success'])
        self.assertEqual(result['summary'], 'Stored description')
        self.assertIn('timed out', result['error'])


class GeminiEndpointRateLimitTest(TestCase):
    def setUp(self):
        cache.clear()
        category = Category.objects.create(name='Technology')
        self.book = Book.objects.create(
            title='Rate Limit Test',
            author='Test Author',
            category=category,
            description='Metadata for the rate-limit test.',
            price=10,
        )

    def tearDown(self):
        cache.clear()

    @patch('books.views.get_gemini_summary', return_value={
        'success': True, 'summary': 'A short test summary.', 'error': None,
    })
    def test_endpoint_allows_ten_requests_per_ip(self, summarize):
        url = reverse('books:ai_summary', args=[self.book.slug])

        responses = [self.client.post(url) for _ in range(11)]

        self.assertEqual(responses[9].status_code, 200)
        self.assertEqual(responses[10].status_code, 429)
        self.assertEqual(summarize.call_count, 10)
