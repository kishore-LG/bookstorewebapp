from django.db import models
from django.utils.text import slugify
from django.core.validators import MinValueValidator, MaxValueValidator


class Category(models.Model):
    """Book category model."""
    name = models.CharField(max_length=100, unique=True)
    slug = models.SlugField(max_length=120, unique=True, blank=True)
    description = models.TextField(blank=True)
    icon = models.CharField(max_length=50, default='bi-book', help_text='Bootstrap icon class')

    class Meta:
        verbose_name_plural = 'Categories'
        ordering = ['name']

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)


class Book(models.Model):
    """Book model with all relevant fields."""
    title = models.CharField(max_length=255)
    author = models.CharField(max_length=255)
    isbn = models.CharField(max_length=20, unique=True, blank=True, null=True)
    category = models.ForeignKey(
        Category, on_delete=models.SET_NULL, null=True, related_name='books'
    )
    description = models.TextField()
    price = models.DecimalField(
        max_digits=8, decimal_places=2,
        validators=[MinValueValidator(0.01)]
    )
    discount_price = models.DecimalField(
        max_digits=8, decimal_places=2,
        null=True, blank=True,
        validators=[MinValueValidator(0.01)]
    )
    cover_image = models.ImageField(
        upload_to='book_covers/', blank=True, null=True
    )
    cover_image_url = models.URLField(
        max_length=500, blank=True,
        help_text='Remote URL for book cover image (used if no uploaded image)'
    )
    stock = models.PositiveIntegerField(default=10)
    average_rating = models.DecimalField(
        max_digits=3, decimal_places=1, default=4.0,
        validators=[MinValueValidator(0.0), MaxValueValidator(5.0)]
    )
    publication_date = models.DateField(null=True, blank=True)
    date_added = models.DateTimeField(auto_now_add=True)
    is_best_seller = models.BooleanField(default=False)
    is_new_arrival = models.BooleanField(default=False)
    is_featured = models.BooleanField(default=False)
    has_audiobook = models.BooleanField(default=False)
    slug = models.SlugField(max_length=300, unique=True, blank=True)

    class Meta:
        ordering = ['-date_added']

    def __str__(self):
        return f"{self.title} by {self.author}"

    def save(self, *args, **kwargs):
        if not self.slug:
            base_slug = slugify(self.title)
            slug = base_slug
            counter = 1
            while Book.objects.filter(slug=slug).exclude(pk=self.pk).exists():
                slug = f"{base_slug}-{counter}"
                counter += 1
            self.slug = slug
        super().save(*args, **kwargs)

    @property
    def effective_price(self):
        """Return discount price if available, else regular price."""
        return self.discount_price if self.discount_price else self.price

    @property
    def discount_percentage(self):
        """Calculate discount percentage if discount price exists."""
        if self.discount_price and self.price > 0:
            return int((1 - self.discount_price / self.price) * 100)
        return 0

    @property
    def get_cover_image(self):
        """Return the cover image URL (local or remote)."""
        if self.cover_image:
            return self.cover_image.url
        if self.cover_image_url:
            return self.cover_image_url
        return f"https://via.placeholder.com/300x400/2c3e50/ffffff?text={self.title[:15]}"

    def star_range(self):
        """Return a range for star rating display."""
        return range(1, 6)


class Review(models.Model):
    """Book review model."""
    book = models.ForeignKey(Book, on_delete=models.CASCADE, related_name='reviews')
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    rating = models.PositiveSmallIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)]
    )
    comment = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('book', 'user')
        ordering = ['-created_at']

    def __str__(self):
        return f"Review by {self.user.username} for {self.book.title}"
