document.addEventListener('DOMContentLoaded', () => {
    const backToTop = document.getElementById('backToTop');
    if (backToTop) {
        const updateBackToTop = () => {
            backToTop.classList.toggle('visible', window.scrollY > 480);
        };
        window.addEventListener('scroll', updateBackToTop, { passive: true });
        updateBackToTop();
        backToTop.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches
                    ? 'instant'
                    : 'smooth',
            });
        });
    }

    document.querySelectorAll('.newsletter-form, .newsletter-form-hero').forEach((form) => {
        form.addEventListener('submit', async (event) => {
            event.preventDefault();
            const button = form.querySelector('[type="submit"]');
            let status = form.querySelector('[data-newsletter-status]');
            if (!status) {
                status = document.createElement('p');
                status.dataset.newsletterStatus = 'true';
                status.setAttribute('role', 'status');
                form.append(status);
            }

            if (button) button.disabled = true;
            status.textContent = 'Submitting...';
            try {
                const response = await fetch(form.action, {
                    method: 'POST',
                    body: new FormData(form),
                    headers: { 'X-Requested-With': 'XMLHttpRequest' },
                });
                const result = await response.json();
                status.textContent = result.message || 'Subscription could not be completed.';
                status.className = result.success ? 'text-success' : 'text-danger';
                if (result.success) form.reset();
            } catch (error) {
                status.textContent = 'Network error. Please try again.';
                status.className = 'text-danger';
            } finally {
                if (button) button.disabled = false;
            }
        });
    });
});
