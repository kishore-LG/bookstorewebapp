# BookHaven Online Book Store

A responsive Django bookstore with SQLite, session-based carts, dummy checkout, user accounts, newsletter subscriptions, Django Admin, and an optional Gemini-powered reading guide. No payment data is collected.

## Requirements

- Python 3.11 or newer (Python 3.11 is recommended for the included Windows script)
- Internet access for installing Python packages and loading remote Open Library cover images
- A Gemini API key only if you want AI summaries; the store works without one

## Quick setup on Windows

1. Extract the ZIP, open the `online_book_store` folder in VS Code, then open a terminal in that folder.
2. Run `setup.bat`. It creates `.venv`, installs packages, applies migrations, seeds sample books, optionally opens the interactive superuser prompt, and starts the server.
3. Open http://127.0.0.1:8000/ . Django Admin is at http://127.0.0.1:8000/admin/ .

The setup script does not set or store an administrator password. Answer `Y` when asked to create a superuser and follow Django's prompts, or run the command below later. Without a configured `SECRET_KEY`, Django generates a temporary key at startup for local development; set a private persistent value in `.env` before deployment. Generate one with `python -c "from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())"`.

## Manual setup

### Windows PowerShell

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
Copy-Item .env.example .env
python manage.py migrate
python manage.py seed_data
python manage.py createsuperuser
python manage.py runserver
```

If PowerShell blocks environment activation, run the virtual environment's executable directly (for example, `.venv\Scripts\python.exe manage.py migrate`). The `.env` file is optional for local use and must not be committed.

### Linux / macOS

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
cp .env.example .env
python manage.py migrate
python manage.py seed_data
python manage.py createsuperuser
python manage.py runserver
```

`seed_data` can be run repeatedly; existing sample books are skipped. To remove existing books and categories before seeding, run `python manage.py seed_data --clear`.

## Gemini summaries (optional)

1. Create an API key in Google AI Studio: https://aistudio.google.com/app/apikey .
2. Put it in the local `.env` file as `GEMINI_API_KEY=your-real-key`. Keep `.env` private and never place the key in templates or JavaScript.
3. Restart the server. The backend calls Google's Gemini `generateContent` REST API using the configurable `GEMINI_MODEL` (default `gemini-2.5-flash`), with a 30-second read timeout and a per-IP limit of 10 requests per hour.

When the key is absent or Gemini is unavailable, the detail page shows the stored book description and a friendly status message. Generated output is an AI-created reading guide based on metadata, not a verified synopsis.

## Useful commands

```bash
python manage.py check
python manage.py test
python manage.py makemigrations --check --dry-run
```

SQLite is the default database. Migrations create the schema on a fresh installation. Uploaded covers are stored in `media/`; sample cover images use remote Open Library URLs and therefore require an internet connection to display. Django's development server is for local coursework and is not a production deployment configuration.

## Included features

- Dynamic home page with featured, best-selling, and new-arrival books
- Search by title, author, or ISBN; category and price filtering; sorting and pagination
- Registration, login, profile editing, order history, and anonymous session cart
- Validated cart and dummy checkout with database-authoritative pricing and stock decrement
- Newsletter subscriptions with duplicate handling
- Admin management for books, categories, newsletter subscribers, and orders
- Optional Gemini reading guides with graceful error handling
