from django.contrib import admin
from .models import Order, OrderItem


class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0
    readonly_fields = ['title', 'author', 'quantity', 'price', 'book']


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = [
        'order_reference', 'first_name', 'last_name', 'email',
        'total_amount', 'status', 'created_at'
    ]
    list_filter = ['status', 'created_at']
    search_fields = ['order_reference', 'email', 'first_name', 'last_name']
    readonly_fields = ['order_reference', 'created_at', 'updated_at']
    list_editable = ['status']
    inlines = [OrderItemInline]
    ordering = ['-created_at']
