from decimal import Decimal

from django.test import TestCase
from django.urls import reverse

from books.models import Book, Category
from .models import Order, OrderItem


class CheckoutTest(TestCase):
    def setUp(self):
        category = Category.objects.create(name='Fiction')
        self.book = Book.objects.create(
            title='Checkout Test Book',
            author='Test Author',
            category=category,
            description='A book used to test checkout.',
            price=Decimal('20.00'),
            discount_price=Decimal('12.00'),
            stock=3,
        )
        self.checkout_url = reverse('orders:checkout')
        self.checkout_data = {
            'first_name': 'Reader',
            'last_name': 'Example',
            'email': 'reader@example.com',
            'phone': '',
            'address': '1 Book Street',
            'city': 'Reading',
            'postal_code': '12345',
            'country': 'India',
            'notes': '',
        }

    def put_book_in_cart(self, quantity, price='0.01'):
        session = self.client.session
        session['cart'] = {
            str(self.book.pk): {'quantity': quantity, 'price': price}
        }
        session.save()

    def test_checkout_uses_current_database_price_and_decrements_stock(self):
        self.put_book_in_cart(quantity=2)

        response = self.client.post(self.checkout_url, self.checkout_data)

        self.assertEqual(response.status_code, 302)
        order = Order.objects.get()
        item = OrderItem.objects.get(order=order)
        self.book.refresh_from_db()
        self.assertEqual(order.total_amount, Decimal('24.00'))
        self.assertEqual(item.price, Decimal('12.00'))
        self.assertEqual(item.quantity, 2)
        self.assertEqual(self.book.stock, 1)
        self.assertEqual(response.url, reverse(
            'orders:order_success', args=[order.order_reference]
        ))
        confirmation = self.client.get(response.url)
        self.assertEqual(confirmation.status_code, 200)
        self.assertEqual(len(order.order_reference), 36)

    def test_checkout_does_not_create_order_for_out_of_stock_book(self):
        self.book.stock = 0
        self.book.save(update_fields=['stock'])
        self.put_book_in_cart(quantity=1)

        response = self.client.post(self.checkout_url, self.checkout_data)

        self.assertEqual(response.status_code, 302)
        self.assertFalse(Order.objects.exists())
        self.assertFalse(OrderItem.objects.exists())

    def test_guest_order_confirmation_is_private_to_originating_session(self):
        order = Order.objects.create(
            first_name='Reader',
            last_name='Example',
            email='reader@example.com',
            address='1 Book Street',
            city='Reading',
            postal_code='12345',
            country='India',
            total_amount=Decimal('12.00'),
        )
        url = reverse('orders:order_success', args=[order.order_reference])

        self.assertEqual(self.client.get(url).status_code, 404)
        session = self.client.session
        session['last_order_reference'] = order.order_reference
        session.save()
        self.assertEqual(self.client.get(url).status_code, 200)
