from django.shortcuts import render, redirect, get_object_or_404
from django.http import Http404
from django.contrib import messages
from django.db import transaction
from django.db.models import F

from .models import Order, OrderItem
from .forms import CheckoutForm
from books.models import Book


class InsufficientStockError(Exception):
    """Raised when inventory changes before an order can be placed."""


def checkout(request):
    """Checkout page: fill in details and create order."""
    cart = request.session.get('cart', {})

    if not cart:
        messages.warning(request, 'Your cart is empty. Please add some books first.')
        return redirect('cart:cart_detail')

    # Rebuild prices from the database; session values are never authoritative.
    cart_items = []
    total = 0
    errors = []

    for book_id, item_data in list(cart.items()):
        try:
            book = Book.objects.get(pk=int(book_id))
            quantity = int(item_data.get('quantity', 1))
            if quantity < 1:
                raise ValueError('Cart quantity must be positive.')
            price = book.effective_price

            if book.stock < quantity:
                if book.stock == 0:
                    errors.append(f'"{book.title}" is out of stock and has been removed from your cart.')
                    del cart[book_id]
                else:
                    errors.append(f'Only {book.stock} copies of "{book.title}" are available. Quantity adjusted.')
                    cart[book_id]['quantity'] = book.stock
                    quantity = book.stock
                request.session['cart'] = cart
                request.session.modified = True

            subtotal = price * quantity
            total += subtotal
            cart_items.append({
                'book': book,
                'quantity': quantity,
                'price': price,
                'subtotal': subtotal,
            })
        except (Book.DoesNotExist, TypeError, ValueError):
            del cart[book_id]
            request.session['cart'] = cart
            request.session.modified = True

    for error in errors:
        messages.warning(request, error)

    if not cart_items:
        messages.warning(request, 'Your cart is empty after validation.')
        return redirect('cart:cart_detail')

    # Pre-fill form with user data if logged in
    initial_data = {}
    if request.user.is_authenticated:
        initial_data = {
            'first_name': request.user.first_name,
            'last_name': request.user.last_name,
            'email': request.user.email,
        }

    if request.method == 'POST':
        form = CheckoutForm(request.POST)
        if form.is_valid():
            try:
                with transaction.atomic():
                    reserved_items = []
                    total = 0
                    for item in cart_items:
                        book_id = item['book'].pk
                        quantity = item['quantity']
                        book = Book.objects.select_for_update().get(pk=book_id)
                        updated = Book.objects.filter(
                            pk=book_id, stock__gte=quantity
                        ).update(stock=F('stock') - quantity)
                        if not updated:
                            raise InsufficientStockError(book.title)
                        price = book.effective_price
                        total += price * quantity
                        reserved_items.append((book, quantity, price))

                    order = Order.objects.create(
                        user=request.user if request.user.is_authenticated else None,
                        first_name=form.cleaned_data['first_name'],
                        last_name=form.cleaned_data['last_name'],
                        email=form.cleaned_data['email'],
                        phone=form.cleaned_data['phone'],
                        address=form.cleaned_data['address'],
                        city=form.cleaned_data['city'],
                        postal_code=form.cleaned_data['postal_code'],
                        country=form.cleaned_data['country'],
                        notes=form.cleaned_data['notes'],
                        total_amount=total,
                    )

                    for book, quantity, price in reserved_items:
                        OrderItem.objects.create(
                            order=order,
                            book=book,
                            title=book.title,
                            author=book.author,
                            quantity=quantity,
                            price=price,
                        )
            except InsufficientStockError as exc:
                messages.error(
                    request,
                    f'We could not place your order because stock changed for "{exc}". '
                    'Please review your cart and try again.',
                )
                return redirect('cart:cart_detail')

            # Clear cart
            request.session['cart'] = {}
            request.session.modified = True
            request.session['last_order_reference'] = order.order_reference

            return redirect('orders:order_success', order_ref=order.order_reference)
    else:
        form = CheckoutForm(initial=initial_data)

    context = {
        'form': form,
        'cart_items': cart_items,
        'total': total,
    }
    return render(request, 'cart/checkout.html', context)


def order_success(request, order_ref):
    """Order confirmation page."""
    order = get_object_or_404(Order, order_reference=order_ref)
    if order.user_id:
        if not request.user.is_authenticated or request.user.pk != order.user_id:
            raise Http404
    elif request.session.get('last_order_reference') != order.order_reference:
        raise Http404
    return render(request, 'cart/order_success.html', {'order': order})


def order_history(request):
    """Show logged-in user's past orders."""
    if not request.user.is_authenticated:
        messages.warning(request, 'Please log in to view your order history.')
        return redirect('accounts:login')
    orders = Order.objects.filter(user=request.user).prefetch_related('items')
    return render(request, 'orders/order_history.html', {'orders': orders})
