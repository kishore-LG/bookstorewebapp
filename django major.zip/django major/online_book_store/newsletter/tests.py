from django.test import TestCase
from django.urls import reverse

from .models import NewsletterSubscriber


class NewsletterSubscriptionTest(TestCase):
    def setUp(self):
        self.url = reverse('newsletter:subscribe')

    def test_valid_email_is_saved_lowercase(self):
        response = self.client.post(self.url, {'email': 'Reader@Example.com'})

        self.assertEqual(response.status_code, 200)
        self.assertTrue(
            NewsletterSubscriber.objects.filter(email='reader@example.com').exists()
        )

    def test_invalid_email_is_rejected(self):
        response = self.client.post(
            self.url,
            {'email': 'not-an-email'},
            HTTP_X_REQUESTED_WITH='XMLHttpRequest',
        )

        self.assertEqual(response.status_code, 400)
        self.assertFalse(NewsletterSubscriber.objects.exists())

    def test_duplicate_email_does_not_create_another_subscriber(self):
        NewsletterSubscriber.objects.create(email='reader@example.com')

        response = self.client.post(
            self.url,
            {'email': 'READER@example.com'},
            HTTP_X_REQUESTED_WITH='XMLHttpRequest',
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(NewsletterSubscriber.objects.count(), 1)
