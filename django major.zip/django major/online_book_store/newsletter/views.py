from django.shortcuts import render, redirect
from django.contrib import messages
from django.views.decorators.http import require_POST
from django.http import JsonResponse

from .models import NewsletterSubscriber
from .forms import NewsletterSubscriptionForm


@require_POST
def subscribe(request):
    """Handle newsletter subscription."""
    form = NewsletterSubscriptionForm(request.POST)
    is_ajax = request.headers.get('X-Requested-With') == 'XMLHttpRequest'

    if not form.is_valid():
        message = 'Please enter a valid email address.'
        if is_ajax:
            return JsonResponse({'success': False, 'message': message}, status=400)
        messages.error(request, message)
        return redirect(request.META.get('HTTP_REFERER', 'books:home'))

    email = form.cleaned_data['email'].strip().lower()
    subscriber, created = NewsletterSubscriber.objects.get_or_create(email=email)
    if not created:
        if not subscriber.is_active:
            subscriber.is_active = True
            subscriber.save(update_fields=['is_active'])
            message = 'Welcome back! Your subscription has been reactivated.'
        else:
            message = 'You are already subscribed to our newsletter!'
        if is_ajax:
            return JsonResponse({'success': True, 'message': message})
        messages.info(request, message)
        return redirect(request.META.get('HTTP_REFERER', 'books:home'))

    message = 'Thank you! You have successfully subscribed to our newsletter.'
    if is_ajax:
        return JsonResponse({'success': True, 'message': message})
    messages.success(request, message)
    return render(request, 'newsletter/subscribe_success.html', {'email': email})
